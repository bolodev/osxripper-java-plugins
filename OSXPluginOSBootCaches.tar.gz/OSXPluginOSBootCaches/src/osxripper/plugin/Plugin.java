package osxripper.plugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.lamora.osxripper.plugin.IPlugin;
import org.lamora.osxripper.plugin.PluginEnum;

/**
 * Plugin to list .playlist files in /private/var/db/BootCaches
 * @author bolodev
 * @version 0.1 initial cut
 * @since 0.1
 */
public class Plugin implements IPlugin {

	private String name;
	private String description;
	private PluginEnum pluginEnum;
	private boolean active;
	
	/**
	 * Constructor
	 */
	public Plugin(){
		setPluginName("BootCaches");
		setPluginDescription("List .playlist files in /private/var/db/BootCaches directory.");
		setPluginEnum(PluginEnum.OS);
		setPluginActive(true);
	}
	
	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginDescription()
	 */
	@Override
	public String getPluginDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginEnum()
	 */
	@Override
	public PluginEnum getPluginEnum() {
		return pluginEnum;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginName()
	 */
	@Override
	public String getPluginName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#isPluginActive()
	 */
	@Override
	public boolean isPluginActive() {
		return active;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#process(java.io.File)
	 */
	@Override
	public String process(File arg0) {
		File uidDirectories = new File(arg0 +  File.separator + "private" + File.separator + "var" + File.separator + "db" + File.separator + "BootCaches");
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("----------").append(System.getProperty("line.separator"));
		sBuilder.append(getPluginName()).append(System.getProperty("line.separator"));
		if(uidDirectories.exists()){
            try {
				ArrayList<File> playLists = FileFinder.findFile(uidDirectories, ".playlist");
				if(playLists.size() == 0){
					sBuilder.append("No .playlist files found.").append(System.getProperty("line.separator"));
				}
				else{
					String currentParent = null;
					for(int i = 0 ; i < playLists.size() ; i++){
						if(currentParent == null || !playLists.get(i).getParentFile().getName().equals(currentParent)){
							sBuilder.append(System.getProperty("line.separator"));
							currentParent = playLists.get(i).getParentFile().getName();
							sBuilder.append('\t').append(currentParent).append(System.getProperty("line.separator"));
						}
						else{
							sBuilder.append("\t\t").append(playLists.get(i).getName()).append(System.getProperty("line.separator"));
						}
					}
				}
			} catch (IOException e) {
				sBuilder.append("IOException:BootCaches: ").append(e.getMessage()).append(System.getProperty("line.separator"));
			}
		}
		else{
			sBuilder.append("/private/var/db/BootCaches does not exist").append(System.getProperty("line.separator"));
		}
		sBuilder.append("Note: The parent UIDs should be corelated to the user UIDs found in the username.plists").append(System.getProperty("line.separator"));
		sBuilder.append(System.getProperty("line.separator")).append("----------").append(System.getProperty("line.separator"));
		return sBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginActive(boolean)
	 */
	@Override
	public void setPluginActive(boolean arg0) {
		active = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginDescription(java.lang.String)
	 */
	@Override
	public void setPluginDescription(String arg0) {
		description = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginEnum(org.lamora.osxripper.plugin.PluginEnum)
	 */
	@Override
	public void setPluginEnum(PluginEnum arg0) {
		pluginEnum = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginName(java.lang.String)
	 */
	@Override
	public void setPluginName(String arg0) {
		name = arg0;
	}

}
