package osxripper.plugin;

import java.util.Scanner;

/**
 * @author bolodev
 *
 */
public class FileScanner {
	
	private static final String NL = System.getProperty("line.separator");

	public static String getScan(String aFileContentToScan, String aPatternToScanFor){
		StringBuilder sBuilder = new StringBuilder();
		Scanner scan = new Scanner(aFileContentToScan);
		scan.useDelimiter("\n");
		while(scan.hasNextLine()){
			String line = scan.nextLine();
			if(line.contains(aPatternToScanFor)){
				sBuilder.append(line).append(NL);
			}
		}
		scan.close();
		return sBuilder.toString();
	}
	
}
