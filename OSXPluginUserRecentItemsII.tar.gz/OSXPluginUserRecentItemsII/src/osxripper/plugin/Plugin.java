package osxripper.plugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.lamora.osxripper.io.Logger;
import org.lamora.osxripper.plugin.IPluginII;
import org.lamora.osxripper.plugin.PluginEnum;
import org.lamora.osxripper.util.GetUserName;
import org.lamora.osxripper.util.PlistRecursor;

/**
 * Plugin to parse users' Library/Preferences/com.apple.recentitems.plist
 * @author bolodev
 * @version 0.1 initial cut
 * @since 0.1
 */
public class Plugin implements IPluginII {

	private String name;
	private String description;
	private PluginEnum pluginEnum;
	private boolean active;
	private File output;
	
	/**
	 * Constructor
	 */
	public Plugin(){
		setPluginName("Recent Items");
		setPluginDescription("Parses com.apple.recentitems.plist in a user's Library/Preferences directory");
		setPluginEnum(PluginEnum.USER);
		setPluginActive(true);
	}
	
	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginDescription()
	 */
	@Override
	public String getPluginDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginEnum()
	 */
	@Override
	public PluginEnum getPluginEnum() {
		return pluginEnum;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginName()
	 */
	@Override
	public String getPluginName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#isPluginActive()
	 */
	@Override
	public boolean isPluginActive() {
		return active;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#process(java.io.File)
	 */
	@Override
	public String process(File arg0) {
		File usersDir = new File(arg0 +  File.separator + "Users");
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("----------").append(System.getProperty("line.separator"));
		sBuilder.append(getPluginName()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
		try {
			ArrayList<File> fileList = FileFinder.findFile(usersDir, "com.apple.recentitems.plist");
			int fileCount = fileList.size();
			if(fileCount == 0){
				sBuilder.append("----------").append(System.getProperty("line.separator"));
				sBuilder.append("No com.apple.recentitems.plist files found").append(System.getProperty("line.separator"));
				sBuilder.append("----------").append(System.getProperty("line.separator"));
				return sBuilder.toString();
			}
			else{
				for(int i = 0 ; i < fileCount ; i++){
					try {
						sBuilder = new StringBuilder();
						String outputPart = GetUserName.getUserNameFromPath(fileList.get(i));
						File outputFile = new File(getOutputDir() + File.separator + getPluginEnum() + "." + outputPart + ".txt");
						sBuilder.append("----------").append(System.getProperty("line.separator"));
						sBuilder.append(fileList.get(i).getAbsolutePath()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
						PlistRecursor pr = new PlistRecursor(fileList.get(i), new String[]{});
						sBuilder.append(pr.dumpPlistToRaw());
						sBuilder.append(System.getProperty("line.separator"));
						sBuilder.append("----------").append(System.getProperty("line.separator"));
						Logger.appendLog(outputFile, sBuilder.toString());
					} catch (Exception e) {
						return "RecentItems Plugin:PlistParserException: " + e.getMessage();
					}
				}
			}
		} catch (IOException e) {
			return "RecentItems Plugin:IOException: " + e.getMessage();
		}
		
		return "User Recent Items written to separate files in: " + output.getAbsolutePath() + System.getProperty("line.separator");
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginActive(boolean)
	 */
	@Override
	public void setPluginActive(boolean arg0) {
		active = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginDescription(java.lang.String)
	 */
	@Override
	public void setPluginDescription(String arg0) {
		description = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginEnum(org.lamora.osxripper.plugin.PluginEnum)
	 */
	@Override
	public void setPluginEnum(PluginEnum arg0) {
		pluginEnum = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginName(java.lang.String)
	 */
	@Override
	public void setPluginName(String arg0) {
		name = arg0;
	}

	@Override
	public File getOutputDir() {
		return output;
	}

	@Override
	public void setOutputDir(File arg0) {
		output = arg0;		
	}

}
