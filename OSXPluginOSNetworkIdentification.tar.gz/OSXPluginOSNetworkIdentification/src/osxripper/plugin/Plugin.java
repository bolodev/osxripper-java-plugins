package osxripper.plugin;

import java.io.File;

import org.lamora.osxripper.plugin.IPlugin;
import org.lamora.osxripper.plugin.PluginEnum;
import org.lamora.osxripper.util.PlistRecursor;

/**
 * Plugin to parse com.apple.network.identification.plist in /Library/Preferences/SystemConfiguration
 * @author bolodev
 * @version 0.1 initial cut
 * @since 0.1
 */
public class Plugin implements IPlugin {

	private String name;
	private String description;
	private PluginEnum pluginEnum;
	private boolean active;
	
	/**
	 * Constructor
	 */
	public Plugin(){
		setPluginName("Network Identification");
		setPluginDescription("Parses com.apple.network.identification.plist in the /Library/Preferences/SystemConfiguration directory. Pulls out network identity information.");
		setPluginEnum(PluginEnum.OS);
		setPluginActive(true);
	}
	
	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginDescription()
	 */
	@Override
	public String getPluginDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginEnum()
	 */
	@Override
	public PluginEnum getPluginEnum() {
		return pluginEnum;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginName()
	 */
	@Override
	public String getPluginName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#isPluginActive()
	 */
	@Override
	public boolean isPluginActive() {
		return active;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#process(java.io.File)
	 */
	@Override
	public String process(File arg0) {
		File networkPlist = new File(arg0 
				+ File.separator + "Library" 
				+ File.separator + "Preferences"
				+ File.separator + "SystemConfiguration"
				+ File.separator + "com.apple.network.identification.plist");
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("----------").append(System.getProperty("line.separator"));
		sBuilder.append(getPluginName()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
		if(networkPlist.exists()){
			try {
				PlistRecursor pr = new PlistRecursor(networkPlist, new String[]{});
				sBuilder.append(pr.dumpPlistToRaw());
//				NSDictionary rootDict = (NSDictionary) PropertyListParser.parse(networkPlist);
//				NSArray sigsArray = (NSArray) rootDict.objectForKey("Signatures");
//				int arrayCount = sigsArray.count();
//				for(int i = 0 ; i < arrayCount ; i++){
//					NSDictionary tempDict = (NSDictionary) sigsArray.objectAtIndex(i);
//					//Identifier
//					sBuilder.append("Identifier: ").append(tempDict.objectForKey("Identifier").toString()).append(System.getProperty("line.separator"));
//					//Signature
//					sBuilder.append("Signature: ").append(tempDict.objectForKey("Signature").toString()).append(System.getProperty("line.separator"));
//					//Timestamp
//					sBuilder.append("Timestamp: ").append(tempDict.objectForKey("Timestamp").toString()).append(System.getProperty("line.separator"));
//					sBuilder.append(System.getProperty("line.separator"));
//					//Services - NSArray
//					sBuilder.append("Services:").append(System.getProperty("line.separator"));
//					NSArray servicesArray = (NSArray) tempDict.objectForKey("Services");
//					int servicesCount = servicesArray.count();
//					for(int j = 0 ; j < servicesCount ; j++){
//						//ServiceID
//						NSDictionary servicesDict = (NSDictionary) servicesArray.objectAtIndex(j);
//						sBuilder.append('\t').append("ServiceID: ").append(servicesDict.objectForKey("ServiceID").toString()).append(System.getProperty("line.separator"));
//						//DNS
//						sBuilder.append('\t').append("----- DNS -----").append(System.getProperty("line.separator"));
//						NSDictionary dnsDict = (NSDictionary) servicesDict.objectForKey("DNS");
//						if(dnsDict.containsKey("DomainName")){
//							sBuilder.append('\t').append("DomainName: ").append(dnsDict.objectForKey("DomainName").toString()).append(System.getProperty("line.separator"));
//						}
//						NSArray serverAddrArray = (NSArray) dnsDict.objectForKey("ServerAddresses");
//						int serverAddrCount = serverAddrArray.count();
//						sBuilder.append('\t').append("ServerAddresses:").append(System.getProperty("line.separator"));
//						for(int k = 0 ; k < serverAddrCount ; k++){
//							sBuilder.append('\t').append(serverAddrArray.objectAtIndex(k).toString()).append(System.getProperty("line.separator"));
//						}
//						
//						//IPv4
//						sBuilder.append('\t').append("----- IPv4 -----").append(System.getProperty("line.separator"));
//						NSDictionary ipv4Dict = (NSDictionary) servicesDict.objectForKey("IPv4");
//						//InterfaceName
//						sBuilder.append('\t').append("InterfaceName: ").append(ipv4Dict.objectForKey("InterfaceName").toString()).append(System.getProperty("line.separator"));
//						//Router
//						sBuilder.append('\t').append("Router: ").append(ipv4Dict.objectForKey("Router").toString()).append(System.getProperty("line.separator"));
//						//Addresses - NSArray
//						NSArray addrArray = (NSArray) ipv4Dict.objectForKey("Addresses");
//						for(int l = 0 ; l < addrArray.count() ; l++){
//							sBuilder.append('\t').append("Addresses: ").append(addrArray.objectAtIndex(l).toString()).append(System.getProperty("line.separator"));
//						}
//						//SubnetMasks - NSArray
//						NSArray subnetArray = (NSArray) ipv4Dict.objectForKey("SubnetMasks");
//						for(int l = 0 ; l < addrArray.count() ; l++){
//							sBuilder.append('\t').append("SubnetMasks: ").append(subnetArray.objectAtIndex(l).toString()).append(System.getProperty("line.separator"));
//						}
//						sBuilder.append(System.getProperty("line.separator"));
//					}
					sBuilder.append(System.getProperty("line.separator"));
//				}
				
//				sBuilder.append(System.getProperty("line.separator"));
			} catch (Exception e) {
				sBuilder.append("com.apple.network.identification.plist: ").append(e.getMessage()).append(System.getProperty("line.separator"));
			}
		}
		else{
			sBuilder.append("com.apple.network.identification.plist does not exist").append(System.getProperty("line.separator"));
		}
		sBuilder.append("----------").append(System.getProperty("line.separator"));
		return sBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginActive(boolean)
	 */
	@Override
	public void setPluginActive(boolean arg0) {
		active = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginDescription(java.lang.String)
	 */
	@Override
	public void setPluginDescription(String arg0) {
		description = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginEnum(org.lamora.osxripper.plugin.PluginEnum)
	 */
	@Override
	public void setPluginEnum(PluginEnum arg0) {
		pluginEnum = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginName(java.lang.String)
	 */
	@Override
	public void setPluginName(String arg0) {
		name = arg0;
	}

}
