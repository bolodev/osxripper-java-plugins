package osxripper.plugin;

import java.io.File;
import java.io.IOException;

import org.lamora.osxripper.plugin.IPlugin;
import org.lamora.osxripper.plugin.PluginEnum;

/**
 * Plugin to parse DHCP lease plists in /private/var/db/dhcpclient/leases
 * @author bolodev
 * @version 0.1 initial cut
 * @since 0.1
 */
public class Plugin implements IPlugin {

	private String name;
	private String description;
	private PluginEnum pluginEnum;
	private boolean active;
	
	/**
	 * Constructor
	 */
	public Plugin(){
		setPluginName("DHCP Leases");
		setPluginDescription("Parses DHCP lease plists in the /private/var/db/dhcpclient/leases directory.");
		setPluginEnum(PluginEnum.OS);
		setPluginActive(true);
	}
	
	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginDescription()
	 */
	@Override
	public String getPluginDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginEnum()
	 */
	@Override
	public PluginEnum getPluginEnum() {
		return pluginEnum;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginName()
	 */
	@Override
	public String getPluginName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#isPluginActive()
	 */
	@Override
	public boolean isPluginActive() {
		return active;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#process(java.io.File)
	 */
	@Override
	public String process(File arg0) {
		File dhcpLeaseDir = new File(arg0 + File.separator + "private" +  File.separator + "var" + File.separator + "db" +  File.separator + "dhcpclient" + File.separator + "leases");
		StringBuilder sBuilder = new StringBuilder();
		File[] leaseFiles = dhcpLeaseDir.listFiles();
		try{
			sBuilder.append("----------").append(System.getProperty("line.separator"));
			sBuilder.append(getPluginName()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
			if(leaseFiles == null || leaseFiles.length == 0){
				sBuilder.append("No DHCP Lease files found.").append(System.getProperty("line.separator"));
				sBuilder.append(System.getProperty("line.separator"));
				sBuilder.append("----------").append(System.getProperty("line.separator"));
			}
			else{
				for(File f : leaseFiles){
					sBuilder.append("Lease File: ").append(f.getName()).append(System.getProperty("line.separator"));
					PlistRecursorImpl pri = new PlistRecursorImpl(f);
					sBuilder.append(pri.dumpPlistToRaw());
					sBuilder.append(System.getProperty("line.separator"));
				}
				sBuilder.append(System.getProperty("line.separator"));
				sBuilder.append("----------").append(System.getProperty("line.separator"));
			}
		}
		catch(IOException e){
			return sBuilder.append("IOException:DHCP Leases: ").append(e.getMessage()).append(System.getProperty("line.separator")).toString();
		}
		catch(Exception e){
			return sBuilder.append("Exception:DHCP Leases: ").append(e.getMessage()).append(System.getProperty("line.separator")).toString();
		}
		return sBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginActive(boolean)
	 */
	@Override
	public void setPluginActive(boolean arg0) {
		active = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginDescription(java.lang.String)
	 */
	@Override
	public void setPluginDescription(String arg0) {
		description = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginEnum(org.lamora.osxripper.plugin.PluginEnum)
	 */
	@Override
	public void setPluginEnum(PluginEnum arg0) {
		pluginEnum = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginName(java.lang.String)
	 */
	@Override
	public void setPluginName(String arg0) {
		name = arg0;
	}

}
