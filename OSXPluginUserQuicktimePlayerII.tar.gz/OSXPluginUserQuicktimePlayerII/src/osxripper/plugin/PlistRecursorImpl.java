package osxripper.plugin;

import java.io.File;

import org.lamora.osxripper.util.PlistRecursor;

import com.dd.plist.NSObject;

/**
 * @author bolodev
 *
 */
public class PlistRecursorImpl extends PlistRecursor {

	private String[] watchKeys = new String[]{
			"FullscreenPreferenceBackgroundColorData",
			"FullscreenPreferenceStandardSize",
			"FullscreenPreferenceSize",
			"GeneralPreferenceNumberOfRecentItems",
			"GeneralPreferencePlaySoundWhenAppInBackground",
			"QTPContentGuideWindowLocation",
			"GeneralPreferenceShowTimeCodeAbsoluteFrameNumbers",
			"GeneralPreferenceAutoPlayMoviesWhenOpened",
			"FullscreenPreferenceScreenNumber",
			"FullscreenPreferenceEnableHUD",
			"FullscreenPreferenceHUDFadeOutTime",
			"dataRef",
			"CapturePreferenceFormatIdentifier",
			"FullscreenPreferenceCaptureAllDisplays",
			"GeneralPreferencePauseMoviesWhenLoggedOut",
			"GeneralPreferenceHighQualityVideo",
			"FullscreenPreferenceSlideShowMode",
			"NSOpenGLAutoscaleBounds",
			"GeneralPreferencePlaySoundInFrontPlayerOnly",
			"GeneralPreferenceShowHotPicksMovieAutomatically",
			"GeneralPreferenceOpenMoviesInNewPlayers",
			"GeneralPreferenceShowClosedCaptioning",
			"GeneralPreferenceHideSelectionIndicators",
			"GeneralPreferenceShowTimeCode",
			"GeneralPreferenceShowSubtitles",
			"FullscreenPreferenceWidescreenSize",
			"kFullscreenPreferenceRemainInFullScreenWhenInactive",
			"MetaPreferenceImportedOldPrefsVersion",
			"GeneralPreferenceEnableProAppsColorCompatibilityMode",
			"GeneralPreferenceShowEqualizer"
	};
	
	public PlistRecursorImpl(File aPlistToScan) {
		super(aPlistToScan);
		for(String key : watchKeys){
			watchList.add(key);
		}
	}
	
	/*
	 * (non-Javadoc)
	 * @see org.lamora.osxripper.util.PlistRecursor#parseWatchKey(java.lang.String, com.dd.plist.NSObject, int)
	 */
	protected String parseWatchKey(String aKey, NSObject anObject, int anIndentLevel){
    	return "";
    } 

}
