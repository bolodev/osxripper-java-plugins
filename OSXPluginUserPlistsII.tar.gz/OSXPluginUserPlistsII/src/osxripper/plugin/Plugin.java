package osxripper.plugin;

import java.io.File;

import org.lamora.osxripper.io.Logger;
import org.lamora.osxripper.plugin.IPluginII;
import org.lamora.osxripper.plugin.PluginEnum;

/**
 * Parses username.plists from /private/var/db/dslocal/nodes/Default/users
 * @author bolodev
 * @version 0.1
 * @since 0.1
 */
public class Plugin implements IPluginII {
	
	private String name;
	private String description;
	private PluginEnum pluginEnum;
	private boolean active;
	private File output;
	
	public Plugin(){
		setPluginName("User Plists");
		setPluginDescription("Parses username.plists from /private/var/db/dslocal/nodes/Default/users. Pulls out username, home, default shell, uid, gid, shadow hash.");
		setPluginEnum(PluginEnum.USER);
		setPluginActive(true);
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginDescription()
	 */
	@Override
	public String getPluginDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginEnum()
	 */
	@Override
	public PluginEnum getPluginEnum() {
		return pluginEnum;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginName()
	 */
	@Override
	public String getPluginName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#isPluginActive()
	 */
	@Override
	public boolean isPluginActive() {
		return active;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#process(java.io.File)
	 */
	@Override
	public String process(File arg0) {
		File dirToScan = new File(arg0 
				+ File.separator + "private" 
		        + File.separator + "var" 
				+ File.separator + "db" 
		        + File.separator + "dslocal" 
				+ File.separator + "nodes" 
		        + File.separator + "Default"
		        + File.separator + "users");
		File[] userFiles = dirToScan.listFiles();
		
		for(File f : userFiles){
			String outputPart = f.getName().replace(".plist", "");
			File outputFile = new File(getOutputDir() + File.separator + getPluginEnum() + "." + outputPart + ".txt");
			StringBuilder sBuilder = new StringBuilder();
			if(f.getName().endsWith(".plist") && f.length() > 0L){
				sBuilder.append("----------").append(System.getProperty("line.separator"));
				sBuilder.append(f.getAbsolutePath()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
				try {
					PlistRecursorImpl pr = new PlistRecursorImpl(f, new String[]{"mcx_settings"});
					sBuilder.append(pr.dumpPlistToRaw());
					sBuilder.append(System.getProperty("line.separator"));
				} catch (Exception e) {
					sBuilder.append("User Plists:Exception: ").append(e.getMessage()).append(System.getProperty("line.separator"));
				}
				sBuilder.append(System.getProperty("line.separator"));
				sBuilder.append("----------").append(System.getProperty("line.separator"));
				Logger.appendLog(outputFile, sBuilder.toString());
			}
		}
		return "User Plists written to separate files in: " + output.getAbsolutePath() + System.getProperty("line.separator");
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginActive(boolean)
	 */
	@Override
	public void setPluginActive(boolean arg0) {
		active = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginDescription(java.lang.String)
	 */
	@Override
	public void setPluginDescription(String arg0) {
		description = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginEnum(org.lamora.osxripper.plugin.PluginEnum)
	 */
	@Override
	public void setPluginEnum(PluginEnum arg0) {
		pluginEnum = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginName(java.lang.String)
	 */
	@Override
	public void setPluginName(String arg0) {
		name = arg0;
	}

	@Override
	public void setOutputDir(File aDirectory) {
		output = aDirectory;
	}

	@Override
	public File getOutputDir() {
		return output;
	}

}
