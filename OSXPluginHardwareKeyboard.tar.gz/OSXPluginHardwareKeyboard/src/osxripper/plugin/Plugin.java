package osxripper.plugin;

import java.io.File;

import org.lamora.osxripper.plugin.IPlugin;
import org.lamora.osxripper.plugin.PluginEnum;
import org.lamora.osxripper.util.PlistRecursor;

/**
 * Plugin to parse com.apple.HIToolbox.plist in /Library/Preferences
 * @author bolodev
 * @version 0.1 initial cut
 * @since 0.1
 */
public class Plugin implements IPlugin {

	private String name;
	private String description;
	private PluginEnum pluginEnum;
	private boolean active;
	
	/**
	 * Constructor
	 */
	public Plugin(){
		setPluginName("Keyboard");
		setPluginDescription("Parses com.apple.HIToolbox.plist in the /Library/Preferences directory. Pulls out keyboard settings information.");
		setPluginEnum(PluginEnum.HARDWARE);
		setPluginActive(true);
	}
	
	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginDescription()
	 */
	@Override
	public String getPluginDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginEnum()
	 */
	@Override
	public PluginEnum getPluginEnum() {
		return pluginEnum;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginName()
	 */
	@Override
	public String getPluginName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#isPluginActive()
	 */
	@Override
	public boolean isPluginActive() {
		return active;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#process(java.io.File)
	 */
	@Override
	public String process(File arg0) {
		File keyboardPlist = new File(arg0 +  File.separator + "Library" + File.separator + "Preferences" + File.separator + "com.apple.HIToolbox.plist");
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("----------").append(System.getProperty("line.separator"));
		sBuilder.append(getPluginName()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
		if(keyboardPlist.exists()){
			try {
				PlistRecursor pr = new PlistRecursor(keyboardPlist, new String[]{});
				sBuilder.append(pr.dumpPlistToRaw());
//				NSDictionary rootDict = (NSDictionary) PropertyListParser.parse(irControllerPlist);
//				//AppleCurrentKeyboardLayoutInputSourceID
//				sBuilder.append("AppleCurrentKeyboardLayoutInputSourceID: ").append(rootDict.objectForKey("AppleCurrentKeyboardLayoutInputSourceID")).append(System.getProperty("line.separator"));
//				sBuilder.append(System.getProperty("line.separator"));
//				
//				//AppleDefaultAsciiInputSource - NSDictionary
//				NSDictionary sourceDict = (NSDictionary) rootDict.objectForKey("AppleDefaultAsciiInputSource");
//				sBuilder.append("AppleDefaultAsciiInputSource:").append(System.getProperty("line.separator"));
//				HashMap<String, NSObject> sourceMap = sourceDict.getHashMap();
//				for(String s : sourceMap.keySet()){
//					sBuilder.append('\t').append(s).append(": ").append(sourceMap.get(s).toString()).append(System.getProperty("line.separator"));
//				}
//				sBuilder.append(System.getProperty("line.separator"));
//				
//				//AppleEnabledInputSources - NSArray
//				NSArray sourcesArray = (NSArray) rootDict.objectForKey("AppleEnabledInputSources");
//				int arrayCount = sourcesArray.count();
//				sBuilder.append("AppleCurrentKeyboardLayoutInputSourceID:").append(System.getProperty("line.separator"));
//				for(int i = 0 ; i < arrayCount ; i++){
//					NSDictionary tempDict = (NSDictionary) sourcesArray.objectAtIndex(i);
//					HashMap<String, NSObject> tempMap = tempDict.getHashMap();
//					for(String s : tempMap.keySet()){
//						sBuilder.append('\t').append(s).append(": ").append(tempMap.get(s).toString()).append(System.getProperty("line.separator"));
//					}
//					sBuilder.append(System.getProperty("line.separator"));					
//				}
//				
//				//AppleInputSourceHistory - NSArray
//				sourcesArray = (NSArray) rootDict.objectForKey("AppleInputSourceHistory");
//				arrayCount = sourcesArray.count();
//				sBuilder.append("AppleInputSourceHistory:").append(System.getProperty("line.separator"));
//				for(int i = 0 ; i < arrayCount ; i++){
//					NSDictionary tempDict = (NSDictionary) sourcesArray.objectAtIndex(i);
//					HashMap<String, NSObject> tempMap = tempDict.getHashMap();
//					for(String s : tempMap.keySet()){
//						sBuilder.append('\t').append(s).append(": ").append(tempMap.get(s).toString()).append(System.getProperty("line.separator"));
//					}
//					sBuilder.append(System.getProperty("line.separator"));					
//				}
//				
//				//AppleSelectedInputSources - NSArray
//				sourcesArray = (NSArray) rootDict.objectForKey("AppleSelectedInputSources");
//				arrayCount = sourcesArray.count();
//				sBuilder.append("AppleSelectedInputSources:").append(System.getProperty("line.separator"));
//				for(int i = 0 ; i < arrayCount ; i++){
//					NSDictionary tempDict = (NSDictionary) sourcesArray.objectAtIndex(i);
//					HashMap<String, NSObject> tempMap = tempDict.getHashMap();
//					for(String s : tempMap.keySet()){
//						sBuilder.append('\t').append(s).append(": ").append(tempMap.get(s).toString()).append(System.getProperty("line.separator"));
//					}
//					sBuilder.append(System.getProperty("line.separator"));					
//				}
				sBuilder.append(System.getProperty("line.separator"));
			} catch (Exception e) {
				sBuilder.append("com.apple.HIToolbox.plist Exception: ").append(e.getMessage()).append(System.getProperty("line.separator"));
			}
		}
		else{
			sBuilder.append("com.apple.HIToolbox.plist does not exist").append(System.getProperty("line.separator"));
		}
		sBuilder.append("----------").append(System.getProperty("line.separator"));
		return sBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginActive(boolean)
	 */
	@Override
	public void setPluginActive(boolean arg0) {
		active = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginDescription(java.lang.String)
	 */
	@Override
	public void setPluginDescription(String arg0) {
		description = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginEnum(org.lamora.osxripper.plugin.PluginEnum)
	 */
	@Override
	public void setPluginEnum(PluginEnum arg0) {
		pluginEnum = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginName(java.lang.String)
	 */
	@Override
	public void setPluginName(String arg0) {
		name = arg0;
	}

}
