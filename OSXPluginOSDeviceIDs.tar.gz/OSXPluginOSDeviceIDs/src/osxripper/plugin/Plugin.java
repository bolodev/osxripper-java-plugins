package osxripper.plugin;

import java.io.File;

import org.lamora.osxripper.plugin.IPlugin;
import org.lamora.osxripper.plugin.PluginEnum;
import org.lamora.osxripper.util.PlistRecursor;

/**
 * Plugin to parse [sha hash].plist in /private/var/db/lockdown
 * @author bolodev
 * @version 0.1 initial cut
 * @since 0.1
 */
public class Plugin implements IPlugin {

	private String name;
	private String description;
	private PluginEnum pluginEnum;
	private boolean active;
	
	/**
	 * Constructor
	 */
	public Plugin(){
		setPluginName("Device IDs");
		setPluginDescription("Parses [sha hash].plist/s and SystemConfiguration.plist in the /private/var/db/lockdown directory. Pulls out System IDs.");
		setPluginEnum(PluginEnum.OS);
		setPluginActive(true);
	}
	
	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginDescription()
	 */
	@Override
	public String getPluginDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginEnum()
	 */
	@Override
	public PluginEnum getPluginEnum() {
		return pluginEnum;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginName()
	 */
	@Override
	public String getPluginName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#isPluginActive()
	 */
	@Override
	public boolean isPluginActive() {
		return active;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#process(java.io.File)
	 */
	@Override
	public String process(File arg0) {
		File certfileDir = new File(arg0 +  File.separator + "private" + File.separator + "var" + File.separator + "db" + File.separator + "lockdown");
		File[] certFiles = certfileDir.listFiles();
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("----------").append(System.getProperty("line.separator"));
		sBuilder.append(getPluginName()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
		
		for(File f : certFiles){
			if(f.getName().equalsIgnoreCase("SystemConfiguration.plist")){
				try {
					sBuilder.append(f.getAbsolutePath()).append(System.getProperty("line.separator"));
					PlistRecursor pr = new PlistRecursor(f, new String[]{});
					sBuilder.append(pr.dumpPlistToRaw());
//					NSDictionary rootDict = (NSDictionary) PropertyListParser.parse(f);
//					HashMap<String, NSObject> configMap = rootDict.getHashMap();
//					for(String s : configMap.keySet()){
//						sBuilder.append(s).append(": ").append(configMap.get(s).toString()).append(System.getProperty("line.separator"));
//					}
					sBuilder.append(System.getProperty("line.separator"));
				} catch (Exception e) {
					sBuilder.append(getPluginName()).append(":Exception: ").append(e.getMessage()).append(System.getProperty("line.separator"));
				}
			}
			else{ //it's one of the sha hash named files
				if(f.getName().endsWith(".plist")){
					sBuilder.append(f.getAbsolutePath()).append(System.getProperty("line.separator"));
					try {
						sBuilder.append(f.getAbsolutePath()).append(System.getProperty("line.separator"));
						PlistRecursor pr = new PlistRecursor(f, new String[]{});
						sBuilder.append(pr.dumpPlistToRaw());
//						NSDictionary rootDict = (NSDictionary) PropertyListParser.parse(f);
//						HashMap<String, NSObject> rootMap = rootDict.getHashMap();
//						for(String s : rootMap.keySet()){
//							if(s.endsWith("ID")){
//								sBuilder.append(s).append(": ").append(rootMap.get(s).toString()).append(System.getProperty("line.separator"));
//							}
//						}
						sBuilder.append(System.getProperty("line.separator"));
					} catch (Exception e) {
						sBuilder.append(getPluginName()).append(":Exception: ").append(e.getMessage()).append(System.getProperty("line.separator"));
					}
				}
			}
		}
		
		sBuilder.append("----------").append(System.getProperty("line.separator"));
		return sBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginActive(boolean)
	 */
	@Override
	public void setPluginActive(boolean arg0) {
		active = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginDescription(java.lang.String)
	 */
	@Override
	public void setPluginDescription(String arg0) {
		description = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginEnum(org.lamora.osxripper.plugin.PluginEnum)
	 */
	@Override
	public void setPluginEnum(PluginEnum arg0) {
		pluginEnum = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginName(java.lang.String)
	 */
	@Override
	public void setPluginName(String arg0) {
		name = arg0;
	}

}
