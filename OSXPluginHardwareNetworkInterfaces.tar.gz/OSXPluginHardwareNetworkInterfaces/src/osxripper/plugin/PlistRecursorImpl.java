package osxripper.plugin;

import java.io.File;
import java.io.IOException;

import org.lamora.osxripper.util.PlistRecursor;

import com.dd.plist.Base64;
import com.dd.plist.NSData;
import com.dd.plist.NSObject;

/**
 * @author bolodev
 *
 */
public class PlistRecursorImpl extends PlistRecursor {

	/**
	 * Constrructor
	 * @param aPlistToScan plist to parse
	 * @param aKeyArray list of keys to process
	 */
	public PlistRecursorImpl(File aPlistToScan, String[] aKeyArray) {
		super(aPlistToScan, aKeyArray);
	}
	
	/*
	 * (non-Javadoc)
	 * @see org.lamora.osxripper.util.PlistRecursor#parseWatchKey(java.lang.String, com.dd.plist.NSObject, int)
	 */
	protected String parseWatchKey(String aKey, NSObject anObject, int anIndentLevel){
		StringBuilder sBuilder = new StringBuilder();
		if(aKey.equals("IOMACAddress")){
			try {
				sBuilder.append(indentTabs(anIndentLevel)).append(aKey).append(": ");
				NSData macData = (NSData) anObject;
				byte[] macBytes = Base64.decode(macData.getBase64EncodedData());
				for(int j = 0 ; j < macBytes.length ; j++){
					if(j != macBytes.length-1){
						sBuilder.append(String.format("%02X", macBytes[j])).append(":");
					}
					else{
						sBuilder.append(String.format("%02X", macBytes[j])).append(NL);
					}
				}
			} catch (IOException e) {
				sBuilder.append(indentTabs(anIndentLevel+1)).append(aKey).append(":Exception: ").append(e.getMessage()).append(NL);
			}
			
		}
    	return sBuilder.toString();
    }

}
