/**
 * 
 */
package osxripper.plugin;

import java.io.File;

import org.lamora.osxripper.util.PlistRecursor;

import com.dd.plist.NSObject;

/**
 * @author bolodev
 *
 */
public class PlistRecursorImpl extends PlistRecursor {

	private String[] watchKeys = new String[]{
			"TableColumns",
			"NSWindow Frame Preferences",
			"DateCellWidthCache",
			"RSSDefaultFeedsVersion",
			"NSPreferencesContentSize"};
	
	public PlistRecursorImpl(File aPlistToScan) {
		super(aPlistToScan);
		for(String key : watchKeys){
			watchList.add(key);
		}
	}
	
	protected String parseWatchKey(String aKey, NSObject anObject, int anIndentLevel){
    	return "";
    }

}
