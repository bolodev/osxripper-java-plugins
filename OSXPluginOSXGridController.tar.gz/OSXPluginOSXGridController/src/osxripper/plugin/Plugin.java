package osxripper.plugin;

import java.io.File;

import org.lamora.osxripper.plugin.IPlugin;
import org.lamora.osxripper.plugin.PluginEnum;
import org.lamora.osxripper.util.PlistRecursor;

/**
 * Plugin to parse com.apple.xgrid.controller.plist in /Library/Preferences
 * @author bolodev
 * @version 0.1 initial cut
 * @since 0.1
 */
public class Plugin implements IPlugin {

	private String name;
	private String description;
	private PluginEnum pluginEnum;
	private boolean active;
	
	/**
	 * Constructor
	 */
	public Plugin(){
		setPluginName("XGrid Controller");
		setPluginDescription("Parses com.apple.xgrid.controller.plist in the /Library/Preferences directory. Pulls out XGrid configuration information.");
		setPluginEnum(PluginEnum.OS);
		setPluginActive(true);
	}
	
	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginDescription()
	 */
	@Override
	public String getPluginDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginEnum()
	 */
	@Override
	public PluginEnum getPluginEnum() {
		return pluginEnum;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginName()
	 */
	@Override
	public String getPluginName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#isPluginActive()
	 */
	@Override
	public boolean isPluginActive() {
		return active;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#process(java.io.File)
	 */
	@Override
	public String process(File arg0) {
		File xgridPlist = new File(arg0 +  File.separator + "Library" + File.separator + "Preferences" + File.separator + "com.apple.xgrid.controller.plist");
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("----------").append(System.getProperty("line.separator"));
		sBuilder.append(getPluginName()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
		if(xgridPlist.exists()){
			try {
				PlistRecursor pr = new PlistRecursor(xgridPlist, new String[]{});
				sBuilder.append(pr.dumpPlistToRaw());
				sBuilder.append(System.getProperty("line.separator"));
			} catch (Exception e) {
				sBuilder.append("com.apple.xgrid.controller.plist Exception: ").append(e.getMessage()).append(System.getProperty("line.separator"));
			}
		}
		else{
			sBuilder.append("com.apple.xgrid.controller.plist does not exist").append(System.getProperty("line.separator"));
		}
		sBuilder.append("----------").append(System.getProperty("line.separator"));
		return sBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginActive(boolean)
	 */
	@Override
	public void setPluginActive(boolean arg0) {
		active = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginDescription(java.lang.String)
	 */
	@Override
	public void setPluginDescription(String arg0) {
		description = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginEnum(org.lamora.osxripper.plugin.PluginEnum)
	 */
	@Override
	public void setPluginEnum(PluginEnum arg0) {
		pluginEnum = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginName(java.lang.String)
	 */
	@Override
	public void setPluginName(String arg0) {
		name = arg0;
	}

}
