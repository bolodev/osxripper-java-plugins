package osxripper.plugin;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import org.lamora.osxripper.util.KMPMatch;
import org.lamora.osxripper.util.PlistRecursor;

import com.dd.plist.Base64;
import com.dd.plist.NSArray;
import com.dd.plist.NSData;
import com.dd.plist.NSObject;

/**
 * @author bolodev
 *
 */
public class PlistRecursorImpl extends PlistRecursor {

	private byte[] guidSig = new byte[]{(byte)0x41, (byte) 0xb1, (byte)0x4d, (byte)0x51, (byte)0x0f, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x24, (byte)0x00, (byte)0x00, (byte)0x00,(byte)0x01,(byte)0x01,(byte)0x00,(byte)0x00};
	private byte[] asciiSig = new byte[]{(byte)0x06, (byte)0xa0, (byte)0x2e, (byte)0x00, (byte)0x06, (byte)0xa0, (byte)0x2b, (byte)0x00, (byte)0x02, (byte)0x00};

	private String[] watchKeys = new String[]{
		"MGRecentURLPropertyLists"
	};
	
	public PlistRecursorImpl(File aPlistToScan) {
		super(aPlistToScan);
		for(String key : watchKeys){
			watchList.add(key);
		}
	}
	
	/*
	 * (non-Javadoc)
	 * @see org.lamora.osxripper.util.PlistRecursor#parseWatchKey(java.lang.String, com.dd.plist.NSObject, int)
	 */
	protected String parseWatchKey(String aKey, NSObject anObject, int anIndentLevel){
		StringBuilder sb = new StringBuilder();
		if(aKey.equals("MGRecentURLPropertyLists")){
			//array -> data
			
			NSArray plistArray = (NSArray)anObject;
			for(int i = 0 ; i < plistArray.count() ; i++){
				NSObject tempObject = plistArray.objectAtIndex(i);
				if(tempObject instanceof NSData){
					try {
						byte[] tempBytes = Base64.decode(((NSData)tempObject).getBase64EncodedData());
						KMPMatch kmp = new KMPMatch();
						int offsetToGUID =  kmp.indexOf(tempBytes, guidSig);
						int offsetToAsciiPath = kmp.indexOf(tempBytes, asciiSig);
						if(offsetToGUID != -1){
							int guid = offsetToGUID + guidSig.length;
							byte[] guidBytes = Arrays.copyOfRange(tempBytes, guid, guid + 36);
							sb.append(indentTabs(anIndentLevel)).append("GUID:").append(NL);
							sb.append(indentTabs(anIndentLevel+1)).append(new String(guidBytes)).append(NL);
						}
						else{
							sb.append(indentTabs(anIndentLevel+1)).append("No byte signature found for GUID").append(NL);
						}
						if(offsetToAsciiPath != -1){
							int ascii = offsetToAsciiPath + asciiSig.length;
							int len = tempBytes[ascii] &0xffff;
							byte[] asciiBytes = Arrays.copyOfRange(tempBytes, ascii +1, ascii +1 + len);
							sb.append(indentTabs(anIndentLevel)).append("File:").append(NL);
							sb.append(indentTabs(anIndentLevel+1)).append(new String(asciiBytes)).append(NL);
						}
						else{
							sb.append(indentTabs(anIndentLevel+1)).append("No byte signature found for ASCII file name").append(NL);
						}
					} catch (IOException e) {
						return "MGRecentURLPropertyLists:IOException: " + e.getMessage();
					}
				}
			}
		}
    	return sb.toString();
    } 

}
