package osxripper.plugin;

import java.io.File;

import org.lamora.osxripper.util.PlistRecursor;

import com.dd.plist.NSObject;

/**
 * @author bolodev
 *
 */
public class PlistRecursorImpl extends PlistRecursor {

	private String[] watchKeys = new String[]{
		"PreferencesDialogLocation",
		"OutgoingCallSound",
		"AudioVolume",
		"NSNavSidebarWidth",
		"InstantMessageWindowSize",
		"NewMessageSound",
		"HIToolbar Config com.microsoft.messenger.toolbar.CorporateContactWindow",
		"HistoryViewerSize",
		"PersonalContactWindowSize",
		"InstantMessageTextStyles",
		"GetInfoLocation",
		"PreferredMediaTypes",
		"DotNetAccountSettingsLocation",
		"MediaDriftRateThreshold",
		"PreferencesTabValue",
		"UserTileChooserLocation",
		"HideGALSearchPane",
		"AddedToContactListDialogLocation",
		"HIToolbar Config com.microsoft.messenger.toolbar.PersonalInstantMessage",
		"SuppressContactSounds",
		"NSNavBrowserPreferedColumnContentWidth",
		"MediaSpeakerVar",
		"DoNotShowUnblockAlert",
		"SignInDialogLocation",
		"HidePersonalSearchPane",
		"AboutBoxLocation",
		"HIToolbar Config com.microsoft.messenger.toolbar.HistoryWindow",
		"HideInlineDisplayPictures",
		"fBonjourCollapsed",
		"OfflineCollapses",
		"HistoryViewerLocation",
		"HideCustomEmoticons",
		"NSNavPanelExpandedSizeForOpenMode:GetFile:0",
		"DontBounceDockIcon",
		"DoNotShowArchivePrefChangedAlert",
		"DisableSpellAsYouType",
		"ContactOnlineSound",
		"NewMailSound",
		"IncomingCallSound",
		"BounceOnlyOnce",
		"InstantMessageWindowLocation",
		"HIToolbar Config com.microsoft.messenger.toolbar.InstantMessage",
		"EnableAlertsForDoNotDisturb",
		"NewAlertSound",
		"NSNavPanelExpandedSizeForOpenMode:ChooseFolder:0",
		"HideCorporateContactsWindow",
		"GroupOfflineTogether",
		"Tuned",
		"AutoIdleDelay",
		"WebContinuousSpellCheckingEnabled",
		"HideDisplayPictureDrawer",
		"AvailableOnFullScreen",
		"PersonalContactWindowLocation",
		"HIToolbar Config com.microsoft.messenger.toolbar.PersonalContactWindow",
		"CorporateContactWindowSize",
		"HideIncomingVideoToasts",
		"fBonjourCollapsedSIP",
		"CorporateContactWindowLocation",
		"ShowMessagePreview",
		"HideIncomingCallToasts",
		"NextNewVersionNotifyTime",
		"HideEmoticons",
		"DoNotShowDropOutOfIMAlert"
	};
	
	public PlistRecursorImpl(File aPlistToScan) {
		super(aPlistToScan);
		for(String key : watchKeys){
			watchList.add(key);
		}
	}
	
	/*
	 * (non-Javadoc)
	 * @see org.lamora.osxripper.util.PlistRecursor#parseWatchKey(java.lang.String, com.dd.plist.NSObject, int)
	 */
	protected String parseWatchKey(String aKey, NSObject anObject, int anIndentLevel){
    	return "";
    } 

}
