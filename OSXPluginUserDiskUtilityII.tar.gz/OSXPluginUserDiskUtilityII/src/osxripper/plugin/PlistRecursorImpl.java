package osxripper.plugin;

import java.io.File;

import org.lamora.osxripper.util.PlistRecursor;

import com.dd.plist.NSObject;

/**
 * @author bolodev
 *
 */
public class PlistRecursorImpl extends PlistRecursor {

	public PlistRecursorImpl(File aPlistToScan, String[] aKeyArray) {
		super(aPlistToScan, aKeyArray);
	}
	
	/*
	 * (non-Javadoc)
	 * @see org.lamora.osxripper.util.PlistRecursor#parseWatchKey(java.lang.String, com.dd.plist.NSObject, int)
	 */
	protected String parseWatchKey(String aKey, NSObject anObject, int anIndentLevel){
    	return "";
    }

}
