package osxripper.plugin;

import java.io.File;

import org.lamora.osxripper.plugin.IPlugin;
import org.lamora.osxripper.plugin.PluginEnum;

/**
 * Parses .GlobalPreferences.plist from /Library/Preferences
 * @author bolodev
 * @version 0.1
 * @since 0.1
 */
public class Plugin implements IPlugin {
	
	private String name;
	private String description;
	private PluginEnum pluginEnum;
	private boolean active;
	
	public Plugin(){
		setPluginName("Language/Timezone");
		setPluginDescription("Parses .GlobalPreferences.plist from /Library/Preferences. Pulls out Language, TimeZone settings.");
		setPluginEnum(PluginEnum.OS);
		setPluginActive(true);
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginDescription()
	 */
	@Override
	public String getPluginDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginEnum()
	 */
	@Override
	public PluginEnum getPluginEnum() {
		return pluginEnum;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginName()
	 */
	@Override
	public String getPluginName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#isPluginActive()
	 */
	@Override
	public boolean isPluginActive() {
		return active;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#process(java.io.File)
	 */
	@Override
	public String process(File arg0) {
		StringBuilder sBuilder = new StringBuilder();
//		String[] keysToParse = new String[]{ "Country", "AppleLanguages", "com.apple.TimeZonePref.Last_Selected_City", "com.apple.AppleModemSettingTool.LastCountryCode" };
		
		//ColorSyncDevices
		//com.apple.ColorSync.Devices
		//com.apple.windowserver.MainDisplayID
		
		String[] ignoreKeys = new String[]{"ColorSyncDevices","com.apple.ColorSync.Devices","com.apple.windowserver.MainDisplayID"};
		
		File prefsPlist = new File(arg0 
				+ File.separator + "Library" 
		        + File.separator + "Preferences" 
				+ File.separator + ".GlobalPreferences.plist");
		sBuilder.append("----------").append(System.getProperty("line.separator"));
		sBuilder.append(getPluginName()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
		if(prefsPlist.exists()){
			try {
				PlistRecursorImpl pri = new PlistRecursorImpl(prefsPlist, ignoreKeys);
				sBuilder.append(pri.dumpPlistToRaw());
//				NSDictionary rootDict = (NSDictionary) PropertyListParser.parse(prefsPlist);
//				sBuilder.append(keysToParse[0]).append(": ").append(rootDict.objectForKey(keysToParse[0]).toString()).append(System.getProperty("line.separator"));
//				sBuilder.append(System.getProperty("line.separator"));
//				
//				sBuilder.append(keysToParse[3]).append(": ").append(rootDict.objectForKey(keysToParse[3]).toString()).append(System.getProperty("line.separator"));
//				sBuilder.append(System.getProperty("line.separator"));
//				
//				NSArray appleLangs = (NSArray) rootDict.objectForKey(keysToParse[1]);
//				if(appleLangs.count() > 0){
//					for(int i = 0 ; i < appleLangs.count() ; i++){
//						sBuilder.append(keysToParse[1]).append(": ").append(appleLangs.objectAtIndex(i).toString()).append(System.getProperty("line.separator"));
//					}
//				}
//				else{
//					sBuilder.append(keysToParse[1]).append(": ").append("No languages specified").append(System.getProperty("line.separator"));
//				}
//				sBuilder.append(System.getProperty("line.separator"));
//				
//				NSArray tzArray = (NSArray) rootDict.objectForKey(keysToParse[2]);
//				if(tzArray.count() > 0){
//					sBuilder.append(keysToParse[2]).append(": ").append(System.getProperty("line.separator"));
//					for(int i = 0 ; i < tzArray.count() ; i++){
//						sBuilder.append('\t').append(tzArray.objectAtIndex(i).toString()).append(System.getProperty("line.separator"));
//					}
//				}
//				else{
//					sBuilder.append(keysToParse[2]).append(": ").append("No timezone or city specified").append(System.getProperty("line.separator"));
//				}
				sBuilder.append(System.getProperty("line.separator"));
			} catch (Exception e) {
				sBuilder.append("Langs & Timezones:Exception: ").append(e.getMessage()).append(System.getProperty("line.separator"));
			}
		}
		else{
			sBuilder.append("/Library/Preferences/.GlobalPreferences.plist does not exist.").append(System.getProperty("line.separator"));
		}
		sBuilder.append("----------").append(System.getProperty("line.separator"));
		return sBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginActive(boolean)
	 */
	@Override
	public void setPluginActive(boolean arg0) {
		active = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginDescription(java.lang.String)
	 */
	@Override
	public void setPluginDescription(String arg0) {
		description = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginEnum(org.lamora.osxripper.plugin.PluginEnum)
	 */
	@Override
	public void setPluginEnum(PluginEnum arg0) {
		pluginEnum = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginName(java.lang.String)
	 */
	@Override
	public void setPluginName(String arg0) {
		name = arg0;
	}

}
