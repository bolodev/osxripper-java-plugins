package osxripper.plugin;

import java.io.File;

import org.lamora.osxripper.plugin.IPlugin;
import org.lamora.osxripper.plugin.PluginEnum;
import org.lamora.osxripper.util.PlistRecursor;

/**
 * Plugin to parse /Library/Caches/com.apple.DisgnosticReporting.Networks.plist
 * @author bolodev
 * @version 0.1 initial cut
 * @since 0.1
 */
public class Plugin implements IPlugin {
	
	private String name;
	private String description;
	private PluginEnum pluginEnum;
	private boolean active;
	
	/**
	 * Constructor
	 */
	public Plugin(){
		setPluginName("Diagnostic Reporting Networks");
		setPluginDescription("Parses ExternalSignatures key to get IPV4 Router details found in /Library/Caches/com.apple.DiagnosticReporting.Networks.plist");
		setPluginEnum(PluginEnum.OS);
		setPluginActive(true);
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginDescription()
	 */
	@Override
	public String getPluginDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginEnum()
	 */
	@Override
	public PluginEnum getPluginEnum() {
		return pluginEnum;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginName()
	 */
	@Override
	public String getPluginName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#isPluginActive()
	 */
	@Override
	public boolean isPluginActive() {
		return active;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#process(java.io.File)
	 */
	@Override
	public String process(File arg0) {
		StringBuilder outputString = new StringBuilder();
		File plist = new File(arg0 + File.separator + "Library" + File.separator + "Caches" + File.separator + "com.apple.DiagnosticReporting.Networks.plist");
		outputString.append("----------").append(System.getProperty("line.separator"));
		outputString.append(getPluginName()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
		if(plist.exists()){
			try {
				PlistRecursor pr = new PlistRecursor(plist, new String[]{});
				outputString.append(pr.dumpPlistToRaw());
				
//				NSDictionary rootDict = (NSDictionary) PropertyListParser.parse(plist);
//				NSDictionary extSignaturesDictionary = (NSDictionary) rootDict.objectForKey("ExternalSignatures");
//				HashMap<String, NSObject> extHashMap = extSignaturesDictionary.getHashMap();
//				for(String s : extHashMap.keySet()){
//					outputString.append("----------").append(System.getProperty("line.separator"));
//					outputString.append(getPluginName()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
//					outputString.append(s).append(System.getProperty("line.separator"));
//					outputString.append(extHashMap.get(s).toString()).append(System.getProperty("line.separator"));
//					outputString.append("----------").append(System.getProperty("line.separator"));
//				}
			} catch (Exception e) {
				outputString.append("Plist Library parse exception: ").append(e.getMessage());
			}
		}
		else{
			outputString.append("/Library/Caches/com.apple.DiagnosticReportingNetworks.plist does not exist on path: ").append(plist.getAbsolutePath());
		}
		outputString.append("----------").append(System.getProperty("line.separator"));
		return outputString.toString();
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginActive(boolean)
	 */
	@Override
	public void setPluginActive(boolean arg0) {
		active = arg0;

	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginDescription(java.lang.String)
	 */
	@Override
	public void setPluginDescription(String arg0) {
		description = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginEnum(org.lamora.osxripper.plugin.PluginEnum)
	 */
	@Override
	public void setPluginEnum(PluginEnum arg0) {
        pluginEnum = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginName(java.lang.String)
	 */
	@Override
	public void setPluginName(String arg0) {
		name = arg0;
	}

}
