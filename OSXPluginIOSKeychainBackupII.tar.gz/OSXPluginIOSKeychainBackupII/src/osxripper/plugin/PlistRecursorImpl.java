package osxripper.plugin;

import java.io.File;
import java.io.IOException;

import org.lamora.osxripper.util.PlistRecursor;

import com.dd.plist.Base64;
import com.dd.plist.NSData;
import com.dd.plist.NSObject;

/**
 * 
 * @author bolodev
 * @version 0.1
 * @since 0.1
 */
public class PlistRecursorImpl extends PlistRecursor {

	/**
	 * Constructor
	 * @param aPlistToScan plist file to dump
	 * @param aKeyArray the keys to process with parseWatchKey method
	 */
	public PlistRecursorImpl(File aPlistToScan, String[] aKeyArray) {
		super(aPlistToScan, aKeyArray);
	}
	
	/*
	 * (non-Javadoc)
	 * @see org.lamora.osxripper.util.PlistRecursor#parseWatchKey(java.lang.String, com.dd.plist.NSObject, int)
	 */
	protected String parseWatchKey(String aKey, NSObject anObject, int anIndentLevel){
		StringBuilder output = new StringBuilder();
		if(aKey.equals("v_PersistentRef")){
			output.append(indentTabs(anIndentLevel)).append(aKey).append(":").append(NL);
			try {
				NSData persistentRef = (NSData) anObject;
				byte[] refBytes = Base64.decode(persistentRef.getBase64EncodedData());
				output.append(indentTabs(anIndentLevel+1)).append(new String(refBytes)).append(NL);
			} catch (IOException e) {
				return "v_PersistentRef: " + e.getMessage();
			}
		}
		return output.toString();
    }

}
