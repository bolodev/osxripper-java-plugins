package osxripper.plugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import org.lamora.osxripper.io.Logger;
import org.lamora.osxripper.plugin.IPluginII;
import org.lamora.osxripper.plugin.PluginEnum;
import org.lamora.osxripper.util.GetUserName;

import com.dd.plist.NSDictionary;
import com.dd.plist.NSObject;
import com.dd.plist.PropertyListParser;

/**
 * Plugin to parse com.apple.finder.plist in /User/Library/Preferences
 * @author bolodev
 * @version 0.1 initial cut
 * @since 0.1
 */
public class Plugin implements IPluginII {

	private String name;
	private String description;
	private PluginEnum pluginEnum;
	private boolean active;
	private File output;
	
	/**
	 * Constructor
	 */
	public Plugin(){
		setPluginName("Finder");
		setPluginDescription("Parses com.apple.finder.plist in the /User/Library/Preferences directory. Pulls out FXDesktopVolumePositions, NSNavLastRootDirectory, FXConnectToLastURL information.");
		setPluginEnum(PluginEnum.USER);
		setPluginActive(true);
	}
	
	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginDescription()
	 */
	@Override
	public String getPluginDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginEnum()
	 */
	@Override
	public PluginEnum getPluginEnum() {
		return pluginEnum;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginName()
	 */
	@Override
	public String getPluginName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#isPluginActive()
	 */
	@Override
	public boolean isPluginActive() {
		return active;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#process(java.io.File)
	 */
	@Override
	public String process(File arg0) {
		File usersDir = new File(arg0 +  File.separator + "Users");
		StringBuilder sBuilder = new StringBuilder();
		
		try{
			ArrayList<File> prefsFiles = FileFinder.findFile(usersDir, "com.apple.finder.plist");
			int fileCount = prefsFiles.size();
			sBuilder.append("----------").append(System.getProperty("line.separator"));
			sBuilder.append(getPluginName()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
			if(fileCount == 0){
				sBuilder.append("No com.apple.finder.plist files found").append(System.getProperty("line.separator"));
			}
			else{
				for(int i = 0 ; i < fileCount ; i++){
					try {
						sBuilder.append("----------").append(System.getProperty("line.separator"));
						sBuilder.append(prefsFiles.get(i).getAbsolutePath()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
						String outputPart = GetUserName.getUserNameFromPath(prefsFiles.get(i));
						File outputFile = new File(getOutputDir() + File.separator + getPluginEnum() + "." + outputPart + ".txt");
						NSDictionary rootDict = (NSDictionary) PropertyListParser.parse(prefsFiles.get(i));
						//NSNavLastRootDirectory - key
						sBuilder.append("NSNavLastRootDirectory: ").append(rootDict.objectForKey("NSNavLastRootDirectory").toString()).append(System.getProperty("line.separator"));
						//FXConnectToLastURL - key
						sBuilder.append("FXConnectToLastURL: ").append(rootDict.objectForKey("FXConnectToLastURL").toString()).append(System.getProperty("line.separator"));
						//FXDesktopVolumePositions - NSDictionary - keys only
						sBuilder.append("FXDesktopVolumePositions:").append(System.getProperty("line.separator"));
						HashMap<String, NSObject> volMap = ((NSDictionary)rootDict.objectForKey("FXDesktopVolumePositions")).getHashMap();
						ArrayList<String> vols = new ArrayList<String>();
						for(String s : volMap.keySet()){
							vols.add(s);
						}
						Collections.sort(vols);
						for(String s : vols){
							sBuilder.append('\t').append(s).append(System.getProperty("line.separator"));
						}
						sBuilder.append(System.getProperty("line.separator"));
						sBuilder.append("----------").append(System.getProperty("line.separator"));
						Logger.appendLog(outputFile, sBuilder.toString());
					}
					catch(Exception e){
						sBuilder.append("Exception:com.apple.finder.plist: ").append(e.getMessage()).append(System.getProperty("line.separator"));
					}
				}
//				sBuilder.append(System.getProperty("line.separator"));
			}
		}
		catch(IOException e){
			sBuilder.append("Exception:com.apple.finder.plist: ").append(e.getMessage()).append(System.getProperty("line.separator"));
		}
//		sBuilder.append("----------").append(System.getProperty("line.separator"));
		return "com.apple.finder.plist output written to seperate user files.";
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginActive(boolean)
	 */
	@Override
	public void setPluginActive(boolean arg0) {
		active = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginDescription(java.lang.String)
	 */
	@Override
	public void setPluginDescription(String arg0) {
		description = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginEnum(org.lamora.osxripper.plugin.PluginEnum)
	 */
	@Override
	public void setPluginEnum(PluginEnum arg0) {
		pluginEnum = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginName(java.lang.String)
	 */
	@Override
	public void setPluginName(String arg0) {
		name = arg0;
	}

	@Override
	public File getOutputDir() {
		return output;
	}

	@Override
	public void setOutputDir(File arg0) {
		output = arg0;		
	}

}
