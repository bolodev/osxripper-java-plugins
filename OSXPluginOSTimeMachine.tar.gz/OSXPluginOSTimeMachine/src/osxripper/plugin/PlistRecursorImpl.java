package osxripper.plugin;

import java.io.File;
import java.io.IOException;

import org.lamora.osxripper.util.PlistRecursor;

import com.dd.plist.Base64;
import com.dd.plist.NSData;
import com.dd.plist.NSObject;

/**
 * @author bolodev
 *
 */
public class PlistRecursorImpl extends PlistRecursor {

	/**
	 * 
	 * @param aPlistToScan
	 * @param aKeyArray
	 */
	public PlistRecursorImpl(File aPlistToScan, String[] aKeyArray) {
		super(aPlistToScan, aKeyArray);
	}
	
	/*
	 * (non-Javadoc)
	 * @see org.lamora.osxripper.util.PlistRecursor#parseWatchKey(java.lang.String, com.dd.plist.NSObject, int)
	 */
	protected String parseWatchKey(String aKey, NSObject anObject, int anIndentLevel){
		StringBuilder sBuilder = new StringBuilder();
		if(aKey.equals("BackupAlias")){
			sBuilder.append(indentTabs(anIndentLevel)).append(aKey).append(":").append(NL);
			try {
				NSData aliasData = (NSData) anObject;
				String decodedBytes = new String(Base64.decode(aliasData.getBase64EncodedData()));
				int start = decodedBytes.indexOf("/Volumes");
				String processedVolume = decodedBytes.substring(start);
				sBuilder.append(indentTabs(anIndentLevel+1)).append(processedVolume).append(NL);
			} catch (IOException e) {
				sBuilder.append(aKey).append(":Exception: ").append(e.getMessage()).append(NL);
			}
		}
		return sBuilder.toString();
    }
	
}
