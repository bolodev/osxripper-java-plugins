package osxripper.plugin;

import java.io.File;

import org.lamora.osxripper.util.PlistRecursor;

import com.dd.plist.NSObject;

/**
 * @author bolodev
 *
 */
public class PlistRecursorImpl extends PlistRecursor {

	private String[] watchKeys = new String[]{
		"SKCallWndFrame",
		"NSWindow Frame Add Contact Window4",
		"NSTableView Hidden Columns SKHistoryList",
		"NSToolbar Configuration NSPreferences",
		"SKCallPreferencesVoicemailInAdvancedMode",
		"NSWindow Frame SKHistoryWndB",
		"NSTableView Hidden Columns SKHistoryListB",
		"NSTableView Columns SKHistoryList",
		"NSWindow Frame Chat Window",
		"NSPreferencesSelectedIndex",
		"NSToolbar Configuration SKCallToolbarIdentifier",
		"NSWindow Frame SKStartConference",
		"NSTableView Sort Ordering SKHistoryListB",
		"SKSendVideoWndFrame",
		"SKVideoWndFrame",
		"NSNavSidebarWidth",
		"NSNavBrowserPreferedColumnContentWidth",
		"NSNavPanelExpandedSizeForOpenMode",
		"SKShowCallDebugAutomatically",
		"NSToolbar Configuration SKChatToolbarIdentifier",
		"NSTableView Sort Ordering SKHistoryList",
		"SKMainDrawerContentWidth",
		"NSWindow Frame Preferences",
		"EventActions",
		"NSWindow Frame Main Window",
		"NSPreferencesContentSize",
		"ABMainWindowViewMode",
		"NSWindow Frame Search Window4",
		"NSTableView Columns SKHistoryListB",
		"SKToolbarIsHidden",
		"NSWindow Frame File Transfer",
		"NSToolbar Configuration Main Dlg Toolbar Identifier B"
	};
	
	public PlistRecursorImpl(File aPlistToScan) {
		super(aPlistToScan);
		for(String key : watchKeys){
			watchList.add(key);
		}
	}
	
	/*
	 * (non-Javadoc)
	 * @see org.lamora.osxripper.util.PlistRecursor#parseWatchKey(java.lang.String, com.dd.plist.NSObject, int)
	 */
	protected String parseWatchKey(String aKey, NSObject anObject, int anIndentLevel){
    	return "";
    } 

}
