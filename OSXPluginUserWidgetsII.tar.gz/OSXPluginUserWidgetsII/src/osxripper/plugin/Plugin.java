package osxripper.plugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.lamora.osxripper.io.Logger;
import org.lamora.osxripper.plugin.IPluginII;
import org.lamora.osxripper.plugin.PluginEnum;
import org.lamora.osxripper.util.GetUserName;

/**
 * Plugin to list .wdgt folders in /User/Library/Widgets
 * @author bolodev
 * @version 0.1 initial cut
 * @since 0.1
 */
public class Plugin implements IPluginII {

	private String name;
	private String description;
	private PluginEnum pluginEnum;
	private boolean active;
	private File output;
	
	/**
	 * Constructor
	 */
	public Plugin(){
		setPluginName("User Widgets");
		setPluginDescription("List .wdgt folders in /User/Library/Widgets.");
		setPluginEnum(PluginEnum.USER);
		setPluginActive(true);
	}
	
	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginDescription()
	 */
	@Override
	public String getPluginDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginEnum()
	 */
	@Override
	public PluginEnum getPluginEnum() {
		return pluginEnum;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginName()
	 */
	@Override
	public String getPluginName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#isPluginActive()
	 */
	@Override
	public boolean isPluginActive() {
		return active;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#process(java.io.File)
	 */
	@Override
	public String process(File arg0) {
		File usersDir = new File(arg0 +  File.separator + "Users");
		StringBuilder sBuilder = new StringBuilder();
		
		try{
			ArrayList<File> wdgtFiles = FileFinder.findFile(usersDir, ".wdgt");
			int fileCount = wdgtFiles.size();
			if(fileCount == 0){
				sBuilder.append("----------").append(System.getProperty("line.separator"));
				sBuilder.append(getPluginName()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
				sBuilder.append("No widget files found").append(System.getProperty("line.separator"));
				sBuilder.append("----------").append(System.getProperty("line.separator"));
				return sBuilder.toString();
			}
			else{
				
				HashMap<String, ArrayList<File>> tempMap = new HashMap<String, ArrayList<File>>();
				for(int i = 0 ; i < fileCount ; i++){
					String tempPath = wdgtFiles.get(i).getParent();
					if(!tempMap.containsKey(tempPath)){
						tempMap.put(tempPath, new ArrayList<File>());
						tempMap.get(tempPath).add(wdgtFiles.get(i));
					}
					else{
						tempMap.get(tempPath).add(wdgtFiles.get(i));
					}
				}
				
				for(String tempKey : tempMap.keySet()){
					sBuilder = new StringBuilder();
					sBuilder.append("----------").append(System.getProperty("line.separator"));
					sBuilder.append(getPluginName()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
					ArrayList<File> tempList = tempMap.get(tempKey);
					String outputPart = GetUserName.getUserNameFromPath(tempList.get(0));
					File outputFile = new File(getOutputDir() + File.separator + getPluginEnum() + "." + outputPart + ".txt");;
					for(int i = 0 ; i < tempList.size() ; i++){
						sBuilder.append('\t').append(tempList.get(i).getName()).append(System.getProperty("line.separator"));
					}
					sBuilder.append(System.getProperty("line.separator"));
					sBuilder.append("----------").append(System.getProperty("line.separator"));
					Logger.appendLog(outputFile, sBuilder.toString());
				}
			}
		}
		catch(IOException e){
			return sBuilder.append("Exception:User Widgets: ").append(e.getMessage()).append(System.getProperty("line.separator")).toString();
		}
		return "User widgets output written to seperate user files.";
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginActive(boolean)
	 */
	@Override
	public void setPluginActive(boolean arg0) {
		active = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginDescription(java.lang.String)
	 */
	@Override
	public void setPluginDescription(String arg0) {
		description = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginEnum(org.lamora.osxripper.plugin.PluginEnum)
	 */
	@Override
	public void setPluginEnum(PluginEnum arg0) {
		pluginEnum = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginName(java.lang.String)
	 */
	@Override
	public void setPluginName(String arg0) {
		name = arg0;
	}

	@Override
	public File getOutputDir() {
		return output;
	}

	@Override
	public void setOutputDir(File arg0) {
		output = arg0;		
	}

}
