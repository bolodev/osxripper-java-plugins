package osxripper.plugin;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import org.lamora.osxripper.io.Logger;
import org.lamora.osxripper.plugin.IPluginII;
import org.lamora.osxripper.plugin.PluginEnum;
import org.lamora.osxripper.util.GetUserName;

/**
 * Plugin to parse call_history.db database in the file named 2b2b0084a1bc3a5ac8c27afdf14afb42c61a19ca
 * @author bolodev
 * @version 0.1 initial cut
 * @since 0.1
 */
public class Plugin implements IPluginII {

	private String name;
	private String description;
	private PluginEnum pluginEnum;
	private boolean active;
	private File output;
	
	/**
	 * Constructor
	 */
	public Plugin(){
		setPluginName("DB - Call History");
		setPluginDescription("Parses call_history.db database in the file named 2b2b0084a1bc3a5ac8c27afdf14afb42c61a19ca.");
		setPluginEnum(PluginEnum.IOS);
		setPluginActive(true);
	}
	
	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginDescription()
	 */
	@Override
	public String getPluginDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginEnum()
	 */
	@Override
	public PluginEnum getPluginEnum() {
		return pluginEnum;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginName()
	 */
	@Override
	public String getPluginName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#isPluginActive()
	 */
	@Override
	public boolean isPluginActive() {
		return active;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#process(java.io.File)
	 */
	@Override
	public String process(File arg0) {
		File usersDir = new File(arg0 +  File.separator + "Users");
		StringBuilder sBuilder = new StringBuilder();
		try{
			ArrayList<File> prefsFiles = FileFinder.findFile(usersDir, "2b2b0084a1bc3a5ac8c27afdf14afb42c61a19ca");
			
			int fileCount = prefsFiles.size();
			if(fileCount == 0){
				sBuilder.append("----------").append(System.getProperty("line.separator"));
				sBuilder.append(getPluginName()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
				sBuilder.append("No call_history.db file found").append(System.getProperty("line.separator"));
				sBuilder.append("----------").append(System.getProperty("line.separator"));
				return sBuilder.toString();
			}
			else{
				sBuilder = new StringBuilder();
				sBuilder.append("----------").append(System.getProperty("line.separator"));
				sBuilder.append(getPluginName()).append(System.getProperty("line.separator"));
				for(int i = 0 ; i < fileCount ; i++){
					try {
						sBuilder.append(prefsFiles.get(i).getAbsolutePath()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
						String outputPart = GetUserName.getUserNameFromPath(prefsFiles.get(i));
						File outputFile = new File(getOutputDir() + File.separator + getPluginEnum() + "." + outputPart + ".txt");
						
						Class.forName("org.sqlite.JDBC");
					    Connection connection = null;
					    Statement stmt = null;
					    
					    String connString = "jdbc:sqlite:" + prefsFiles.get(i).getAbsolutePath();
					    connection = DriverManager.getConnection(connString);
					    
					    String query = "SELECT id, name, country_code, network_code, address, originalAddress, datetime(date,'unixepoch','localtime') AS 'date', duration, flags FROM call";
					    
					    stmt = connection.createStatement();
					    ResultSet rs = stmt.executeQuery(query);
					    while (rs.next()) {
					    	sBuilder.append("\tID: ").append(rs.getString("account")).append(System.getProperty("line.separator"));
					    	sBuilder.append("\tName: ").append(rs.getString("subject")).append(System.getProperty("line.separator"));
					    	sBuilder.append("\tCountry Code: ").append(rs.getString("text")).append(System.getProperty("line.separator"));
					    	sBuilder.append("\tNetwork Code: ").append(rs.getString("is_delivered")).append(System.getProperty("line.separator"));
					    	sBuilder.append("\tAddress: ").append(rs.getString("is_finished")).append(System.getProperty("line.separator"));
					    	sBuilder.append("\tOriginal Address: ").append(rs.getString("is_read")).append(System.getProperty("line.separator"));
					    	sBuilder.append("\tDate: ").append(rs.getString("is_sent")).append(System.getProperty("line.separator"));
					    	sBuilder.append("\tDuration: ").append(rs.getString("date")).append(System.getProperty("line.separator"));
					    	sBuilder.append("\tFlags: ").append(rs.getString("date_read")).append(System.getProperty("line.separator"));
					    	
					    	sBuilder.append(System.getProperty("line.separator"));
					    }

						sBuilder.append(System.getProperty("line.separator"));
						sBuilder.append("----------").append(System.getProperty("line.separator"));
						Logger.appendLog(outputFile, sBuilder.toString());
					}
					catch(Exception e){
						return sBuilder.append("Exception:call_history.db: ").append(e.getMessage()).append(System.getProperty("line.separator")).toString();
					}
				}
			}
		}
		catch(IOException e){
			return sBuilder.append("Exception:call_history.db: ").append(e.getMessage()).append(System.getProperty("line.separator")).toString();
		}
		return "call_history.db output written to seperate user files.";
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginActive(boolean)
	 */
	@Override
	public void setPluginActive(boolean arg0) {
		active = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginDescription(java.lang.String)
	 */
	@Override
	public void setPluginDescription(String arg0) {
		description = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginEnum(org.lamora.osxripper.plugin.PluginEnum)
	 */
	@Override
	public void setPluginEnum(PluginEnum arg0) {
		pluginEnum = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginName(java.lang.String)
	 */
	@Override
	public void setPluginName(String arg0) {
		name = arg0;
	}

	@Override
	public File getOutputDir() {
		return output;
	}

	@Override
	public void setOutputDir(File arg0) {
		output = arg0;		
	}

}
