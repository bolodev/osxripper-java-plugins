package osxripper.plugin;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import org.lamora.osxripper.util.PlistRecursor;

import com.dd.plist.Base64;
import com.dd.plist.NSData;
import com.dd.plist.NSObject;

/**
 * 
 * @author bolodev
 * @version 0.1
 * @since 0.1
 */
public class PlistRecursorImpl extends PlistRecursor {

	/**
	 * Constructor
	 * @param aPlistToScan plist file to dump
	 * @param aKeyArray the keys to process with parseWatchKey method
	 */
	public PlistRecursorImpl(File aPlistToScan, String[] aKeyArray) {
		super(aPlistToScan, aKeyArray);
	}
	
	/*
	 * (non-Javadoc)
	 * @see org.lamora.osxripper.util.PlistRecursor#parseWatchKey(java.lang.String, com.dd.plist.NSObject, int)
	 */
	protected String parseWatchKey(String aKey, NSObject anObject, int anIndentLevel){
		StringBuilder output = new StringBuilder();
		if(aKey.equals("_NSAlias")){
			output.append(indentTabs(anIndentLevel)).append(aKey).append(":").append(NL);
			//0 - 211 ignore
			//212 - 1 byte hex length of path and name
			try {
				NSData recent = (NSData) anObject;
				byte[] recentBytes = Base64.decode(recent.getBase64EncodedData());
				int len = recentBytes[211] &0xffff;
				byte[] recentFileBytes = Arrays.copyOfRange(recentBytes, 212, 212+len);
				output.append(indentTabs(anIndentLevel+1)).append(new String(recentFileBytes)).append(NL);
			} catch (IOException e) {
				return "_NSAlias:IOException: " + e.getMessage();
			}
		}
		else if(aKey.equals("_DfReceiptCSTs")){
			return "";
		}
		else if(aKey.equals("_DfReceiptPSTs")){
			return "";
		}
		else if(aKey.equals("NSTableView Columns DfLoopBrowserTableViewSettings")){
			return "";
		}
		else if(aKey.equals("NSNavSidebarWidth")){
			return "";
		}
		return output.toString();
    }

}
