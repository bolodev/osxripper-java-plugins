package osxripper.plugin;

import java.io.File;

import org.lamora.osxripper.util.PlistRecursor;

import com.dd.plist.NSObject;

/**
 * @author bolodev
 *
 */
public class PlistRecursorImpl extends PlistRecursor {

	private String[] watchKeys = new String[]{
		"WebKitCacheModelPreferenceKey"
	};
	
	public PlistRecursorImpl(File aPlistToScan) {
		super(aPlistToScan);
		for(String key : watchKeys){
			watchList.add(key);
		}
	}
	
	/*
	 * (non-Javadoc)
	 * @see org.lamora.osxripper.util.PlistRecursor#parseWatchKey(java.lang.String, com.dd.plist.NSObject, int)
	 */
	protected String parseWatchKey(String aKey, NSObject anObject, int anIndentLevel){
    	return "";
    } 

}
