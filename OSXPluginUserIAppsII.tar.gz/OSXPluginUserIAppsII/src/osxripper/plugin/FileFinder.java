package osxripper.plugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
/**
 * Class to scan for Cookies.plist files in a given directory 
 * @author bolodev
 * @version 0.1
 * @since 0.1
 */
public class FileFinder {
	
	/**
	 * Scan for Cookies.plist files in a given directory 
	 * @param aStartPoint the starting directory
	 * @return list of Cookies.plist files
	 * @throws IOException
	 */
	public static ArrayList<File> findPlist(final File aStartPoint) throws IOException{
		final ArrayList<File> cookieFiles = new ArrayList<File>();
		new FileTraversal(){
			public void onFile(final File f) {
				if(f.getName().equalsIgnoreCase("com.apple.iApps.plist")){
					cookieFiles.add(f);
				}
			}
		}.traverse(aStartPoint);
		
		return cookieFiles;
	}
}
