package osxripper.plugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
/**
 * Class to scan for files in a given directory 
 * @author bolodev
 * @version 0.1
 * @since 0.1
 */
public class FileFinder {
	
	/**
	 * Scan for files in a given directory 
	 * @param aStartPoint the starting directory
	 * @param aFileName the name of the file to find
	 * @return list of files
	 * @throws IOException
	 */
	public static ArrayList<File> findFile(final File aStartPoint, final String aFileName) throws IOException{
		final ArrayList<File> searchFiles = new ArrayList<File>();
		new FileTraversal(){
			public void onFile(final File f) {
				try {
					if(f.getAbsolutePath().equals(f.getCanonicalPath())){
						if(f.getName().equalsIgnoreCase(aFileName) ){
							searchFiles.add(f);
						}
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
				
			}
		}.traverse(aStartPoint);
		
		return searchFiles;
	}
}
