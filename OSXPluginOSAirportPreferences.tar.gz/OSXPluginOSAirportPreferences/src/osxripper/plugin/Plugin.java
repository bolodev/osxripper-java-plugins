package osxripper.plugin;

import java.io.File;

import org.lamora.osxripper.plugin.IPlugin;
import org.lamora.osxripper.plugin.PluginEnum;
import org.lamora.osxripper.util.PlistRecursor;

/**
 * Plugin to parse com.apple.airport.preferences.plist in /Library/Preferences/SystemConfiguration
 * @author bolodev
 * @version 0.1 initial cut
 * @since 0.1
 */
public class Plugin implements IPlugin {

	private String name;
	private String description;
	private PluginEnum pluginEnum;
	private boolean active;
	
	/**
	 * Constructor
	 */
	public Plugin(){
		setPluginName("Airport Preferences");
		setPluginDescription("Parses com.apple.airport.preferences.plist in the /Library/Preferences/SystemConfiguration directory. Pulls out known Wifi information.");
		setPluginEnum(PluginEnum.OS);
		setPluginActive(true);
	}
	
	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginDescription()
	 */
	@Override
	public String getPluginDescription() {
		return description;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginEnum()
	 */
	@Override
	public PluginEnum getPluginEnum() {
		return pluginEnum;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#getPluginName()
	 */
	@Override
	public String getPluginName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#isPluginActive()
	 */
	@Override
	public boolean isPluginActive() {
		return active;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#process(java.io.File)
	 */
	@Override
	public String process(File arg0) {
		File airportPlist = new File(arg0 
				+ File.separator + "Library" 
				+ File.separator + "Preferences"
				+ File.separator + "SystemConfiguration"
				+ File.separator + "com.apple.airport.preferences.plist");
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("----------").append(System.getProperty("line.separator"));
		sBuilder.append(getPluginName()).append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
		if(airportPlist.exists()){
			try {
				PlistRecursor pri = new PlistRecursor(airportPlist, new String[]{});
				sBuilder.append(pri.dumpPlistToRaw());
//				NSDictionary rootDict = (NSDictionary) PropertyListParser.parse(airportPlist);
//				HashMap<String, NSObject> rootMap = rootDict.getHashMap();
//				
//				sBuilder.append("Version: ").append(rootMap.get("Version").toString()).append(System.getProperty("line.separator"));
//				sBuilder.append(System.getProperty("line.separator"));
//				
//				NSDictionary knownDict = (NSDictionary) rootMap.get("KnownNetworks");
//				HashMap<String, NSObject> knownMap = knownDict.getHashMap();
//				for(String s : knownMap.keySet()){
//					sBuilder.append(s).append(System.getProperty("line.separator"));
//					NSDictionary tempDict = (NSDictionary) knownMap.get(s);
//					HashMap<String, NSObject> tempMap = tempDict.getHashMap();
//					for(String tm : tempMap.keySet()){
//						if(tm.equalsIgnoreCase("Remembered channels")){
//							NSArray tempChannels = (NSArray) tempMap.get(tm);
//							int arrayCount = tempChannels.count();
//							for(int i = 0 ; i < arrayCount ; i++){
//								sBuilder.append('\t').append("Channel: ").append(tempChannels.objectAtIndex(i).toString()).append(System.getProperty("line.separator"));
//							}
//						}
//						else{
//							sBuilder.append('\t').append(tm).append(": ").append(tempMap.get(tm).toString()).append(System.getProperty("line.separator"));
//						}
//					}
//					sBuilder.append(System.getProperty("line.separator"));
//				}
//				
//				//remove version and known to leave the en* entry/entries
//				rootDict.remove("Version");
//				rootDict.remove("KnownNetworks");
//				for(String s : rootMap.keySet()){
//					NSDictionary enDict = (NSDictionary) rootMap.get(s);
//					NSArray recentArray = (NSArray) enDict.objectForKey("RecentNetworks");
//					int arrayCount = recentArray.count();
//					sBuilder.append(s).append(" RecentNetworks:").append(System.getProperty("line.separator"));
//					for(int i = 0 ; i < arrayCount ; i++){
//						NSDictionary tempDict = (NSDictionary) recentArray.objectAtIndex(i);
//						HashMap<String, NSObject> tempMap = tempDict.getHashMap();
//						for(String tm : tempMap.keySet()){
//							sBuilder.append('\t').append(tm).append(": ").append(tempMap.get(tm).toString()).append(System.getProperty("line.separator"));
//						}
//						sBuilder.append(System.getProperty("line.separator"));
//					}
//				}
				
				sBuilder.append(System.getProperty("line.separator"));
			} catch (Exception e) {
				sBuilder.append("com.apple.airport.preferences.plist Exception: ").append(e.getMessage()).append(System.getProperty("line.separator"));
			}
		}
		else{
			sBuilder.append("com.apple.airport.preferences.plist does not exist").append(System.getProperty("line.separator"));
		}
		sBuilder.append("----------").append(System.getProperty("line.separator"));
		return sBuilder.toString();
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginActive(boolean)
	 */
	@Override
	public void setPluginActive(boolean arg0) {
		active = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginDescription(java.lang.String)
	 */
	@Override
	public void setPluginDescription(String arg0) {
		description = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginEnum(org.lamora.osxripper.plugin.PluginEnum)
	 */
	@Override
	public void setPluginEnum(PluginEnum arg0) {
		pluginEnum = arg0;
	}

	/* (non-Javadoc)
	 * @see org.lamora.osxripper.plugin.IPlugin#setPluginName(java.lang.String)
	 */
	@Override
	public void setPluginName(String arg0) {
		name = arg0;
	}

}
